This code is to explore the US Bikeshare Data as a part of Udacity x Access bank's data science nanodegree program.

The Bikeshare Data is from 3 cities in the US: Chicago, NY and Washington DC

This project helps answer some questions like: the trends in terms of the most common hour, day or month among the riders, others like popular start and stop locations etc.


I used: 
Python 3.7
Numpy library
Pandas library
Windows 10 PC


